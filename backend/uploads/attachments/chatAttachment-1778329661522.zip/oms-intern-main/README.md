
## Project Structure

```
📦 project-root
│── 📁 public                 # Static assets (favicons, images)
│── 📁 src                    # Source code
│   │── 📁 assets             # Images, fonts, global styles
│   │── 📁 components         # Reusable UI components (buttons, cards, etc.)
│   │── 📁 constants          # Static data (menu items, role-based access)
│   │── 📁 context            # Global state/context API (Auth, Theme, etc.)
│   │── 📁 hooks              # Custom React hooks
│   │── 📁 layouts            # Layout components (Header, Sidebar, Footer)
│   │── 📁 pages              # Page components
│   │   │── 📁 public         # Public pages (Home, About, Contact, etc.)
│   │   │── 📁 auth           # Login, Signup, Forgot Password
│   │   │── 📁 dashboard      # Protected dashboard pages
│   │── 📁 routes             # Route definitions & wrappers
│   │── 📁 services           # API calls & database interactions
│   │── 📁 styles             # Tailwind & global styles
│   │── 📁 utils              # Helper functions
│   │── App.jsx               # Main App component
│   │── main.jsx              # React entry point
│── tailwind.config.js        # Tailwind configuration
│── vite.config.js            # Vite configuration
│── package.json
```

## Architecture Overview

### Core Organization Principles

1. **Pages vs Components**
   - `pages/`: Full page components that represent routes
   - `components/`: Reusable UI elements used across multiple pages

2. **Public vs Protected**
   - `pages/public/`: Publicly accessible pages
   - `pages/auth/`: Authentication-related pages
   - `pages/dashboard/`: Protected dashboard pages (requires login)

3. **Service Layer**
   - All API interactions go through the service layer in `services/`
   - Provides a clean separation between UI and data fetching logic

4. **Context for Global State**
   - Global app state is managed through React Context API
   - Auth, theme, and other global contexts in `context/`

5. **Layouts**
   - Common layout components (Header, Sidebar, etc.) are in `layouts/`
   - Promotes consistent UI across the application

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   pnpm install
   ```
3. Copy the environment variables:
   ```bash
   cp .env.example .env
   ```
4. Start the development server:
   ```bash
   pnpm dev
   ```

## Available Scripts

- `pnpm dev` - Start development server
- `pnpm build` - Build for production
- `pnpm preview` - Preview production build
- `pnpm lint` - Run ESLint

## Tech Stack

- **Framework:** React 19
- **Build Tool:** Vite
- **Styling:** TailwindCSS
- **Routing:** React Router DOM
- **HTTP Client:** Axios
- **Icons:** React Icons
- **Loading States:** React Spinners

## Development

The project follows a modular architecture with clear separation of concerns:

- Components are organized by feature/functionality
- Global state is managed through React Context
- Custom hooks for reusable logic
- Error boundaries for graceful error handling
- Lazy loading for optimal performance

## Environment Variables

Copy `.env.example` to `.env` and configure the following variables:

```
VITE_API_URL=your_api_url
```

## Docker Support

### Development with Docker

To run the application in development mode using Docker:

```bash
# Build and start the development container
docker compose up dev
```

The development server will be available at `http://localhost:5173` with hot-reload enabled.

### Production with Docker

To run the application in production mode:

```bash
# Build and start the production container
docker compose up prod -d
```

The production build will be served at `http://localhost:4173` using Vite's preview server.

### Building Docker Images

To build the Docker image manually:

```bash
# Build the production image
docker build -t lunar-oms .
```

### Docker Configuration Files

- `Dockerfile`: Multi-stage build configuration for development and production
- `docker-compose.yml`: Docker Compose configuration for both development and production environments
