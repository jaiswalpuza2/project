import { useEffect, useState } from "react";

function useIsMobile() {

    const MOBILE_BREAKPOINT = import.meta.env.VITE_MOBILE_BREAKPOINT;
    const [isMobile, setIsMobile] = useState(true);

    useEffect(() => {
        const mql = window.matchMedia(
            `(max-width: ${MOBILE_BREAKPOINT - 1}px)`
        );
        const onChange = () => {
            setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
        };
        mql.addEventListener("change", onChange);
        setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
        return () => mql.removeEventListener("change", onChange);
    }, []);

    return !!isMobile;
}

export default useIsMobile;