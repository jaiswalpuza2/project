import { useEffect, useState } from "react";

function useIsSidebarOpen() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
    useEffect(() => {
      const onChange = () => {
        setIsSidebarOpen(!document.querySelector(".sidebar").classList.contains("-translate-x-full"));
      };
      window.addEventListener("resize", onChange);
      onChange();
      return () => window.removeEventListener("resize", onChange);
    }, []);
  
    return isSidebarOpen;
  }

  export default useIsSidebarOpen;