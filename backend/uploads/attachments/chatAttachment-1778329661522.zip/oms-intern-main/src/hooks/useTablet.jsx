import { useEffect, useState } from "react";

function useIsTablet() {
    const TABLET_MIN = import.meta.env.TABLET_MIN;
    const TABLET_MAX = import.meta.env.TABLET_MAX;
    const [isTablet, setIsTablet] = useState(false);

    useEffect(() => {
        const checkIsTablet = () => {
            const width = window.innerWidth;
            setIsTablet(width >= TABLET_MIN && width < TABLET_MAX);
        };

        checkIsTablet();
        window.addEventListener('resize', checkIsTablet);
        return () => window.removeEventListener('resize', checkIsTablet);
    }, []);

    return isTablet;
}

export default useIsTablet;