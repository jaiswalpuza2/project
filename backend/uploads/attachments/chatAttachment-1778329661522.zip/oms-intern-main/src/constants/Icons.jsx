import {
    BsBell,
    BsBook,
    BsBoxArrowRight,
    BsBuilding,
    BsChevronDown,
    BsEnvelope,
    BsExclamationCircle,
    BsFileText,
    BsGear,
    BsGlobe,
    BsHouseDoor,
    BsPerson,
    BsSearch,
    BsShield,
    BsX,
    BsCalendar,
    BsClipboard,
    BsPeople,
    BsCardChecklist,
    BsFileEarmarkText,
    BsCollection,
    BsPersonBadge,
    BsBusFront,
    BsReception4,
    BsPersonLinesFill
} from 'react-icons/bs';
import { IoLibraryOutline } from "react-icons/io5";
import { GiHamburgerMenu } from "react-icons/gi";

export const Icons = {
    // Navigation
    home: BsHouseDoor,
    office: BsBuilding,
    document: BsFileText,
    academic: BsBook,
    library: IoLibraryOutline,
    website: BsGlobe,
    settings: BsGear,
    attendance: BsCalendar,
    serviceManagement: BsClipboard,
    student: BsPeople,
    classroom: BsCardChecklist,
    examination: BsFileEarmarkText,
    sheetPlan: BsCollection,
    result: BsFileText,
    digitalLibrary: BsCollection,
    teacher: BsPersonBadge,
    busTracking: BsBusFront,
    reception: BsReception4,
    userManagement: BsPersonLinesFill,

    // UI Elements
    chevronDown: BsChevronDown,
    search: BsSearch,
    menu: GiHamburgerMenu,
    close: BsX,

    // User Related
    user: BsPerson,
    logout: BsBoxArrowRight,
    notification: BsBell,
    message: BsEnvelope,

    // System
    security: BsShield,
    warning: BsExclamationCircle
};
