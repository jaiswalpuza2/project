import { Icons } from './Icons';
import { createTempComponent } from '../components/temp/TempComponent';
import OfficeList from '../pages/dashboard/office/OfficeList';
import WebSetting from '../pages/dashboard/CompositeExam/CompositeExamPage.jsx';
import CompositeExamPage from '../pages/dashboard/CompositeExam/CompositeExamPage.jsx';

export const sidebarMenu = [
    {
        title: "Office Management",
        to: "office",
        icon: Icons.office,
        items: [
            { 
                title: "Office List", 
                to: "office-list",
                component: OfficeList
            },
            { 
                title: "Branch Office", 
                to: "branch-office",
                component: createTempComponent("Branch Office")
            },
            { 
                title: "Office Setting", 
                to: "office-setting",
                component: createTempComponent("Office Setting")
            },
        ],
    },
    {
        title: "Document Management",
        to: "document-management",
        icon: Icons.document,
        items: [
            { 
                title: "Document Group", 
                to: "document-group",
                component: createTempComponent("Document Group")
            },
            { 
                title: "Office Document", 
                to: "office-document",
                component: createTempComponent("Office Document")
            },
            { 
                title: "Access Control", 
                to: "access-control",
                component: createTempComponent("Access Control")
            },
        ],
    },
    {
        title: "Website",
        to: "website",
        icon: Icons.website,
        items: [
            { 
                title: "Web Contacts", 
                to: "web-contacts",
                component: createTempComponent("Web Contacts")
            },
            { 
                title: "Web Setting", 
                to: "web-setting",
                component: WebSetting
            },
        ],
    },
    {
        title: "Attendance",
        to: "attendance",
        icon: Icons.attendance,
        items: [
            { 
                title: "Attendance Setting", 
                to: "attendance-setting",
                component: createTempComponent("Attendance Setting")
            },
            { 
                title: "Attendance Remarks", 
                to: "attendance-remarks",
                component: createTempComponent("Attendance Remarks")
            },
            { 
                title: "Daily Attendance", 
                to: "daily-attendance",
                component: createTempComponent("Daily Attendance")
            },
            { 
                title: "Attendance Report", 
                to: "attendance-report",
                component: createTempComponent("Attendance Report")
            },
        ],
    },
    {
        title: "Service/ Management",
        to: "service-management",
        icon: Icons.serviceManagement,
        items: [
            { 
                title: "Product List", 
                to: "product-list",
                component: createTempComponent("Product List")
            },
            { 
                title: "Client List", 
                to: "client-list",
                component: createTempComponent("Client List")
            },
            { 
                title: "Online Orders", 
                to: "online-orders",
                component: createTempComponent("Online Orders")
            },
        ],
    },
    {
        title: "Academic Setting",
        to: "academic-setting",
        icon: Icons.academic,
        items: [
            { 
                title: "Student Batch", 
                to: "student-batch",
                component: createTempComponent("Student Batch")
            },
            { 
                title: "Academic Year", 
                to: "academic-year",
                component: createTempComponent("Academic Year")
            },
            { 
                title: "Grade List", 
                to: "grade-list",
                component: createTempComponent("Grade List")
            },
            { 
                title: "Class List", 
                to: "class-list",
                component: createTempComponent("Class List")
            },
        ],
    },
    {
        title: "Student",
        to: "student",
        icon: Icons.student,
        items: [
            { 
                title: "Student List", 
                to: "student-list",
                component: createTempComponent("Student List")
            },
            { 
                title: "Identity Card", 
                to: "identity-card",
                component: createTempComponent("Identity Card")
            },
            { 
                title: "Student Certificate", 
                to: "student-certificate",
                component: createTempComponent("Student Certificate")
            },
            { 
                title: "Shift Student", 
                to: "shift-student",
                component: createTempComponent("Shift Student")
            },
            { 
                title: "Bulk Edit", 
                to: "bulk-edit",
                component: createTempComponent("Bulk Edit")
            },
            { 
                title: "Account Registration", 
                to: "account-registration",
                component: createTempComponent("Account Registration")
            },
            { 
                title: "Online Admission Form", 
                to: "online-admission-form",
                component: createTempComponent("Online Admission Form")
            },
            { 
                title: "Student Profile", 
                to: "student-profile",
                component: createTempComponent("Student Profile")
            },
        ],
    },
    {
        title: "Class-room",
        to: "classroom",
        icon: Icons.classroom,
        items: [
            { 
                title: "Subject List", 
                to: "subject-list",
                component: createTempComponent("Subject List")
            },
            { 
                title: "Class Routine", 
                to: "class-routine",
                component: createTempComponent("Class Routine")
            },
            { 
                title: "Class Logbook", 
                to: "class-logbook",
                component: createTempComponent("Class Logbook")
            },
            { 
                title: "Homework/Assignment", 
                to: "homework-assignment",
                component: createTempComponent("Homework/Assignment")
            },
            { 
                title: "Class-Teacher List", 
                to: "class-teacher-list",
                component: createTempComponent("Class-Teacher List")
            },
            { 
                title: "Class Attendance", 
                to: "class-attendance",
                component: createTempComponent("Class Attendance")
            },
            { 
                title: "Online Class", 
                to: "online-class",
                component: createTempComponent("Online Class")
            },
        ],
    },
    {
        title: "Examination",
        to: "examination",
        icon: Icons.examination,
        items: [
            { 
                title: "Unit Exam", 
                to: "unit-exam",
                component: createTempComponent("Unit Exam")
            },
            { 
                title: "Composite Exam", 
                to: "composite-exam",
                //component: createTempComponent("Composite Exam")
                component: CompositeExamPage
            },
            { 
                title: "Full Mark Setting", 
                to: "full-mark-setting",
                component: createTempComponent("Full Mark Setting")
            },
            { 
                title: "Pass Mark Setting", 
                to: "pass-mark-setting",
                component: createTempComponent("Pass Mark Setting")
            },
            { 
                title: "Grading Scheme", 
                to: "grading-scheme",
                component: createTempComponent("Grading Scheme")
            },
            { 
                title: "Division Criteria", 
                to: "division-criteria",
                component: createTempComponent("Division Criteria")
            },
            { 
                title: "Student Admit Card", 
                to: "student-admit-card",
                component: createTempComponent("Student Admit Card")
            },
        ],
    },
    {
        title: "Sheet Plan",
        to: "sheet-plan",
        icon: Icons.sheetPlan,
        items: [
            { 
                title: "Exam-Room Setting", 
                to: "exam-room-setting",
                component: createTempComponent("Exam-Room Setting")
            },
            { 
                title: "Sheet Planning", 
                to: "sheet-planning",
                component: createTempComponent("Sheet Planning")
            },
            { 
                title: "Sheet Plan Report", 
                to: "sheet-plan-report",
                component: createTempComponent("Sheet Plan Report")
            },
        ],
    },
    {
        title: "Result",
        to: "result",
        icon: Icons.result,
        items: [
            { 
                title: "Mark Entry", 
                to: "mark-entry",
                component: createTempComponent("Mark Entry")
            },
            { 
                title: "Remarks Entry", 
                to: "remarks-entry",
                component: createTempComponent("Remarks Entry")
            },
            { 
                title: "Attendance Entry", 
                to: "attendance-entry",
                component: createTempComponent("Attendance Entry")
            },
            { 
                title: "Ledger Report", 
                to: "ledger-report",
                component: createTempComponent("Ledger Report")
            },
            { 
                title: "Student Report", 
                to: "student-report",
                component: createTempComponent("Student Report")
            },
            { 
                title: "Publish Setting", 
                to: "publish-setting",
                component: createTempComponent("Publish Setting")
            },
        ],
    },
    {
        title: "Library",
        to: "library",
        icon: Icons.library,
        items: [
            { 
                title: "Book Type", 
                to: "book-type",
                component: createTempComponent("Book Type")
            },
            { 
                title: "Subject Group", 
                to: "subject-group",
                component: createTempComponent("Subject Group")
            },
            { 
                title: "Library Setting", 
                to: "library-setting",
                component: createTempComponent("Library Setting")
            },
            { 
                title: "Book List", 
                to: "book-list",
                component: createTempComponent("Book List")
            },
            { 
                title: "Lost Book", 
                to: "lost-book",
                component: createTempComponent("Lost Book")
            },
            { 
                title: "Issue/Return Book", 
                to: "issue-return-book",
                component: createTempComponent("Issue/Return Book")
            },
            { 
                title: "Log Record", 
                to: "log-record",
                component: createTempComponent("Log Record")
            },
        ],
    },
    {
        title: "Digital Library",
        to: "digital-library",
        icon: Icons.digitalLibrary,
        items: [
            { 
                title: "Question Bank", 
                to: "question-bank",
                component: createTempComponent("Question Bank")
            },
            { 
                title: "Class Notes", 
                to: "class-notes",
                component: createTempComponent("Class Notes")
            },
            { 
                title: "Syllabus", 
                to: "syllabus",
                component: createTempComponent("Syllabus")
            },
            { 
                title: "Reading Material", 
                to: "reading-material",
                component: createTempComponent("Reading Material")
            },
        ],
    },
    {
        title: "Teacher",
        to: "teacher",
        icon: Icons.teacher,
        items: [
            { 
                title: "Teacher Routine", 
                to: "teacher-routine",
                component: createTempComponent("Teacher Routine")
            },
            { 
                title: "Teacher Logbook", 
                to: "teacher-logbook",
                component: createTempComponent("Teacher Logbook")
            },
            { 
                title: "Teacher List", 
                to: "teacher-list",
                component: createTempComponent("Teacher List")
            },
            { 
                title: "Teacher Profile", 
                to: "teacher-profile",
                component: createTempComponent("Teacher Profile")
            },
        ],
    },
    {
        title: "Bus Tracking",
        to: "bus-tracking",
        icon: Icons.busTracking,
        items: [
            { 
                title: "Bus Stops", 
                to: "bus-stops",
                component: createTempComponent("Bus Stops")
            },
            { 
                title: "Bus Student", 
                to: "bus-student",
                component: createTempComponent("Bus Student")
            },
            { 
                title: "Find My Bus", 
                to: "find-my-bus",
                component: createTempComponent("Find My Bus")
            },

             { 
                title: "Bus Route", 
                to: "bus-route",
                component: createTempComponent("Bus-Route")
            },
            
        ],
    },
    {
        title: "Reception",
        to: "reception",
        icon: Icons.reception,
        items: [
            { 
                title: "Visitor Tracking", 
                to: "visitor-tracking",
                component: createTempComponent("Visitor Tracking")
            },
            { 
                title: "Office Follow-up", 
                to: "office-followup",
                component: createTempComponent("Office Follow-up")
            },
        ],
    },
    {
        title: "User Management",
        to: "user-management",
        icon: Icons.userManagement,
        items: [
            { 
                title: "User List", 
                to: "user-list",
                component: createTempComponent("User List")
            },
            { 
                title: "Login Management", 
                to: "login-management",
                component: createTempComponent("Login Management")
            },
        ],
    },
    
];