export const HeaderDropDownMenu = [
    { title: "My Profile", to: "myProfile" },
    { title: "Change Password", to: "changePassword" },
    { title: "Logout", to: "logout" },
]