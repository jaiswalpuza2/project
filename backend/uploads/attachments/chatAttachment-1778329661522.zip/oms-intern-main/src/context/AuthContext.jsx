import { createContext, useContext, useState, useEffect } from "react";
import authService from "../services/authService";
import { useNavigate } from "react-router-dom";
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check for existing auth data on mount
    const checkAuth = async () => {
      try {
        const userData = authService.getCurrentUser();
        if (userData.isAuthenticated) {
          setUser(userData);
        }
      } finally {
        setLoading(false);
      }
    };
    
    checkAuth();
  }, []);

  const login = async (credentials) => {
    try {
      const authData = await authService.login(credentials.UserName, credentials.Password);
      
      const userData = {
        token: authData.Token, // Match backend's PascalCase
        name: authData.DisplayName || credentials.UserName,
        isAuthenticated: true
      };
      
      setUser(userData);
      return userData;
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
    
    navigate('/login');
  };

  if (loading) {
    return null;
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout, 
      loading, 
      isAuthenticated: !!user
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthContext;

const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}

export { useAuth };