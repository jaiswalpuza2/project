import React, { Suspense } from 'react';
import MainRoute from './routes/MainRoute';
import ErrorBoundary from './components/common/ErrorBoundary';
import LoadSpinner from './components/common/LoadSpinner';
import { useAuth } from './context/AuthContext';

const App = () => {
  const { loading } = useAuth();

  if (loading) {
    return <LoadSpinner />;
  }

  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadSpinner />}>
        <MainRoute />
      </Suspense>
    </ErrorBoundary>
  );
};

export default App;
