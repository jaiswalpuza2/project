import React, { useEffect, useState } from "react";
import {
  getCompositeExamList,
  insertCompositeExam,
  updateCompositeExam,
  deleteCompositeExam,
} from "../../../services/CompositeExamService.js";

const CompositeExamPage = () => {
  const [exams, setExams] = useState([]);
  const [formData, setFormData] = useState({
    CompositeExamName: "",
    CompositeExamCaption: "",
    MultiplePracticalColumns: false,
    UseFinalFullMark: false,
  });
  const [editId, setEditId] = useState(null);
  const [showInactive, setShowInactive] = useState(false);

  // Fetching
  const fetchExams = async () => {
    try {
      const res = await getCompositeExamList(showInactive);
      let data = res.data || [];

      if (!showInactive) {
        // Only keep active exams
        data = data.filter((exam) => exam.IsActive);
      }

      setExams(data);
    } catch (err) {
      console.error("Error fetching exams:", err);
    }
  };

  useEffect(() => {
    fetchExams();
  }, [showInactive]);

  // Handling input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  // Handling form insert and update
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await updateCompositeExam({ ...formData, CompositeId: editId });
      } else {
        await insertCompositeExam(formData);
      }
      setFormData({
        CompositeExamName: "",
        CompositeExamCaption: "",
        MultiplePracticalColumns: false,
        UseFinalFullMark: false,
      });
      setEditId(null);
      fetchExams();
    } catch (err) {
      console.error("Error saving exam:", err);
    }
  };

  // Edit
  const handleEdit = (exam) => {
    setFormData({
      CompositeExamName: exam.CompositeExamName,
      CompositeExamCaption: exam.CompositeExamCaption,
      MultiplePracticalColumns: exam.MultiplePracticalColumns,
      UseFinalFullMark: exam.UseFinalFullMark,
    });
    setEditId(exam.CompositeId);
  };

  // Delete
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this exam?")) {
      try {
        await deleteCompositeExam(id);
        fetchExams();
      } catch (err) {
        console.error("Error deleting exam:", err);
      }
    }
  };

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">
            Composite Exams
          </h1>
          <button
            onClick={() => setShowInactive((prev) => !prev)}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded"
          >
            {showInactive ? "Hide Inactive" : "Show Inactive"}
          </button>
        </div>

        {/* Form */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">
            {editId ? "Edit Exam" : "Add New Exam"}
          </h2>
          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">
                Exam Name
              </label>
              <input
                name="CompositeExamName"
                value={formData.CompositeExamName}
                onChange={handleChange}
                required
                className="w-full border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">
                Exam Caption
              </label>
              <input
                name="CompositeExamCaption"
                value={formData.CompositeExamCaption}
                onChange={handleChange}
                required
                className="w-full border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                name="MultiplePracticalColumns"
                checked={formData.MultiplePracticalColumns}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600"
              />
              <label className="text-gray-700">
                Multiple Practical Columns
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                name="UseFinalFullMark"
                checked={formData.UseFinalFullMark}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600"
              />
              <label className="text-gray-700">Use Final Full Mark</label>
            </div>

            <div className="md:col-span-2">
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg transition duration-200"
              >
                {editId ? "Update Exam" : "Add Exam"}
              </button>
            </div>
          </form>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-200 text-gray-700">
                <th className="p-3 text-left">Name</th>
                <th className="p-3 text-left">Caption</th>
                <th className="p-3 text-left">Multiple Practical</th>
                <th className="p-3 text-left">Use Final Mark</th>
                <th className="p-3 text-left">Status</th>
                <th className="p-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {exams.length > 0 ? (
                exams.map((exam) => (
                  <tr
                    key={exam.CompositeId}
                    className={`border-t ${
                      !exam.IsActive ? "bg-red-50 text-gray-400" : "hover:bg-gray-50"
                    }`}
                  >
                    <td className="p-3">{exam.CompositeExamName}</td>
                    <td className="p-3">{exam.CompositeExamCaption}</td>
                    <td className="p-3">
                      {exam.MultiplePracticalColumns ? "Yes" : "No"}
                    </td>
                    <td className="p-3">
                      {exam.UseFinalFullMark ? "Yes" : "No"}
                    </td>
                    <td className="p-3">
                      {exam.IsActive ? "Active" : "Inactive"}
                    </td>
                    <td className="p-3 flex gap-2">
                      {exam.IsActive && (
                        <>
                          <button
                            onClick={() => handleEdit(exam)}
                            className="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(exam.CompositeId)}
                            className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                          >
                            Delete
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center p-4 text-gray-500">
                    No exams found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CompositeExamPage;
