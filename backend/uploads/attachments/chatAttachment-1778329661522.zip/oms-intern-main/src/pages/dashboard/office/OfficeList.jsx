import React, { useState, useEffect } from 'react';
import dashboardOfficeService from '../../../services/dashboardOfficeService';
import OfficeCard from '../../../components/dashboard/office/OfficeCard';

const OfficeList = () => {
  const [offices, setOffices] = useState([]);
  const [includeInActive, setIncludeInActive] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const officeLists = await dashboardOfficeService.getlist(includeInActive);
        setOffices(officeLists);
        console.log(officeLists);
      } catch (error) {
        console.error('Error fetching offices:', error);
      }
    })()
  }, [includeInActive]);

  return (
    <div className="p-4">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Office List</h1>
          <p className="text-gray-600">Manage your office locations</p>
        </div>
        
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-600">Show Inactive</label>
          <input
            type="checkbox"
            checked={includeInActive}
            onChange={(e) => setIncludeInActive(e.target.checked)}
            className="form-checkbox h-4 w-4 text-blue-600"
          />
        </div>
      </div>

      <div className="space-y-4">
        {offices?.map((office) => (
          <OfficeCard key={office.OfficeId} office={office} />
        ))}
      </div>
    </div>
  );
};

export default OfficeList;
