import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="flex flex-col items-center justify-center h-screen text-center px-4">
      <h1 className="text-3xl font-bold text-gray-800">🚧 Landing Page Under Construction 🚧</h1>
      <p className="text-lg text-gray-600 mt-2">
        We are working hard to bring something amazing. Stay tuned!
      </p>
      <Link to="/dashboard">
        <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition cursor-pointer">
          Go to Dashboard
        </button>
      </Link>
    </div>
  );
};

export default Home;
