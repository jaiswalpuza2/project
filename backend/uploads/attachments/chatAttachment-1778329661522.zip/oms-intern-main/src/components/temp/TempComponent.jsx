import React from 'react';
import BusRoute from '../dashboard/office/busroute/BusRoute';

const TempComponent = ({title}) => {
  return (
    <div className="p-4">
      {/* <h1 className="text-2xl font-bold">{title}</h1> */}
      {
        title=='Bus-Route' && <div><BusRoute/></div>
      }
      {/* <p>This is a temporary component for {title}</p> */}
    </div>
  );
};

// Create component generator function
export const createTempComponent = (title) => {
  return () => <TempComponent title={title} />;
};

export default TempComponent;
