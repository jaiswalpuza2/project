import { useState, useEffect } from "react";
import { Icons } from "../../constants/Icons";
import Button from "../UI/Button";

const ErrorBoundary = ({ children }) => {
  const [hasError, setHasError] = useState(false);
  const [error, setError] = useState(null);
  const [errorInfo, setErrorInfo] = useState(null);

  useEffect(() => {
    const errorHandler = (event) => {
      setHasError(true);
      setError(event.error);
      setErrorInfo(event.errorInfo);
      console.error("Error:", event.error);
      console.error("Error Info:", event.errorInfo);
    };

    window.addEventListener("error", errorHandler);
    window.addEventListener("unhandledrejection", errorHandler);

    return () => {
      window.removeEventListener("error", errorHandler);
      window.removeEventListener("unhandledrejection", errorHandler);
    };
  }, []);

  const handleReset = () => {
    setHasError(false);
    setError(null);
    setErrorInfo(null);
  };

  if (hasError) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 px-4">
        <div className="text-center max-w-lg">
          <div className="flex justify-center mb-4">
            <Icons.warning className="w-16 h-16 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            Something went wrong
          </h1>
          <p className="text-gray-600 mb-8">
            We apologize for the inconvenience. Please try refreshing the page or contact support if the problem persists.
          </p>
          <div className="space-x-4">
            <Button onClick={() => window.location.reload()} variant="default">
              Refresh Page
            </Button>
            <Button onClick={handleReset} variant="outline">
              Try Again
            </Button>
          </div>
          {import.meta.env.MODE === 'development' && error && (
            <div className="mt-8 text-left">
              <details className="bg-gray-100 p-4 rounded-lg">
                <summary className="text-sm font-medium text-gray-900 cursor-pointer">
                  Error Details
                </summary>
                <pre className="mt-2 text-xs text-red-600 overflow-auto">
                  {error.toString()}
                  {errorInfo?.componentStack}
                </pre>
              </details>
            </div>
          )}
        </div>
      </div>
    );
  }

  return children;
};

export default ErrorBoundary;
