import { useNavigate } from 'react-router-dom';
import Button from '../UI/Button';

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 px-4">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-[var(--color-text-primary)]">404</h1>
        <h2 className="mt-4 text-3xl font-semibold text-gray-900">Page not found</h2>
        <p className="mt-2 text-lg text-gray-600">
          Sorry, we couldn't find the page you're looking for.
        </p>
        <div className="mt-8">
          <Button
            onClick={() => navigate('/')}
            variant="default"
            className="mx-2"
          >
            Go back home
          </Button>
          <Button
            onClick={() => navigate(-1)}
            variant="outline"
            className="mx-2 mt-4 lg:mt-0"
          >
            Go back
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
