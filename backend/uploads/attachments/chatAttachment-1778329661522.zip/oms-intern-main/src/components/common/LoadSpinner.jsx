import { PuffLoader } from 'react-spinners';

const LoadSpinner = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[200px]">
      <PuffLoader color="#004f92" size={60} speedMultiplier={1} />
      <p className="text-lg text-[#004f92] mt-4">Loading...</p>
    </div>
  );
};

export default LoadSpinner;
