
// import axios from 'axios';
// const baseUrl = import.meta.env.VITE_BASE_API_URL
// console.log("This is base url",baseUrl);

// const getToken = ()=>{
//     const token = localStorage.getItem("token");
//     if(!token){
//         console.log("No token found")
//         return;

//     }
//     return token;
// }

