import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../services/axiosInterceptor";
import { FaBusAlt, FaEye, FaEdit, FaTrash } from "react-icons/fa";
import { FiRefreshCw } from "react-icons/fi";
import Dashboard from "./Dashboard";
import { BsWindowPlus } from "react-icons/bs";

const BusRouteList = () => {
  const [route, setRoute] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [totalRoute, setTotalRoute] = useState(null);
  const [selectedRoute, setSelectedRoute] = useState(null); // For view/edit modal
  const [isEditing, setIsEditing] = useState(false);

  const fetchRouteList = async () => {
    try {
      const response = await axiosInstance.get("/BusRoute/GetList");
      setTotalRoute(response.data.length);
      setRoute(response.data);
    } catch (err) {
      console.error("Error fetching routes:", err);
    }
  };

  const handleRefresh = () => {
    window.location.reload();
    setSearchTerm("");
  }

  useEffect(() => {
    fetchRouteList();
  }, []);

  const handleView = async (id) => {
    try {
      // alert("id is"+id);
      const res = await axiosInstance.get(`/BusRoute/GetItem/${id}`);
      console.log("Response from viewing route:", res.data);
      setSelectedRoute(res.data);
      setIsEditing(false);
    } catch (err) {
      console.error("Error viewing route:", err);
    }
  };

  const handleEdit = async (id) => {
    try {
      const res = await axiosInstance.get(`/BusRoute/GetItem/${id}`);
      setSelectedRoute(res.data);
      setIsEditing(true);
    } catch (err) {
      console.error("Error fetching route for edit:", err);
    }
  };

  const handleUpdate = async () => {
    try {
      await axiosInstance.put("/BusRoute/Update", selectedRoute);
      alert("Route updated successfully!");
      setSelectedRoute(null);
      fetchRouteList();
    } catch (err) {
      console.error("Error updating route:", err);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this route?")) return;
    try {
      const response = await axiosInstance.delete(`/BusRoute/Block/${id}`);
        console.log("Response from deleting route:", response);
      alert("Route deleted successfully!");
      fetchRouteList();
    } catch (err) {
      console.error("Error deleting route:", err);
    }
  };

  const filteredRoutes = route.filter(
    (r) =>
      r.BusId?.toString().includes(searchTerm) ||
      r.RouteId?.toString().includes(searchTerm) ||
      r.InTime?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.OutTime?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 bg-blue-50 min-h-screen shadow-md ">
      {/* Search & Refresh */}
      <div className="mt-1 flex gap-3">
        <input
          type="text"
          placeholder="Search bus routes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-1/2 p-4 border border-gray-300 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-gray-300 bg-white "
        />
        <button
          onClick={fetchRouteList}
          className="flex items-center gap-2 px-5 py-3 bg-blue-800 text-white rounded-lg hover:bg-blue-600"
        >
            <div onClick={handleRefresh} className="cursor-pointer flex items-center gap-2">

          <FiRefreshCw /> Refresh
            </div>


        </button>
      </div>

      <Dashboard totalroutes={totalRoute}/>

      {/* Table */}
      <div className="mt-13 bg-white  rounded-lg shadow-2xl overflow-x-auto  border-gray-300 border-2">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-200 text-gray-600  rounded-lg ">
              <th className="p-4">Route Id</th>
              <th className="p-4">Bus Id</th>
              <th className="p-4">Stop Id</th>
              <th className="p-4">In time</th>
              <th className="p-4">Out time</th>
              <th className="p-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredRoutes.length > 0 ? (
              filteredRoutes.map((r, idx) => (
                <tr
                  key={idx}
                  className="border-b last:border- hover:bg-gray-50 border-gray-300 shadow-1xl"
                >
                  <td className="p-4 flex items-center gap-3">
                    <FaBusAlt className="text-blue-700" />
                    <div>
                      <p className="font-medium">{r.RouteId || "Unknown Route"}</p>
                    </div>
                  </td>
                  <td className="p-4">{r.BusId || "--"}</td>
                  <td className="p-4">{r.StopId || "--"}</td>
                  <td className="p-4">{r.InTime || "--"}</td>
                  <td className="p-4">{r.OutTime || "--"}</td>
                  <td className="p-4 flex items-center justify-center gap-3 text-lg">
                    <button
                      title="View"
                      onClick={() => handleView(r.BusId)}
                      className="text-blue-500 hover:text-blue-800"
                    >
                      <FaEye />
                    </button>
                    <button
                      title="Edit"
                      onClick={() => handleEdit(r.BusId)}
                      className="text-green-600 hover:text-green-800"
                    >
                      <FaEdit />
                    </button>
                    <button
                      title="Delete"
                      onClick={() => handleDelete(r.RouteId)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan="6"
                  className="p-6 text-center text-gray-500 italic"
                >
                  No routes found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* View/Edit Modal */}
      {selectedRoute && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40">
          <div className="bg-white rounded-lg p-6 w-96 shadow-lg">
            <h2 className="text-xl font-bold mb-4">
              {isEditing ? "Edit Route" : "Route Details"}
            </h2>

            <div className="space-y-3">
              <input
                type="number"
                value={selectedRoute.RouteId}
                placeholder="Route ID"
                disabled={!isEditing}
                onChange={(e) =>
                  setSelectedRoute({ ...selectedRoute, RouteId: e.target.value })
                }
                className="border rounded p-2 w-full"
              />
              <input
                type="number"
                value={selectedRoute.BusId}
                disabled={!isEditing}
                placeholder="Bus ID"
                onChange={(e) =>
                  setSelectedRoute({ ...selectedRoute, BusId: e.target.value })
                }
                className="border rounded p-2 w-full"
              />
              <input
                type="number"
                value={selectedRoute.StopId}
                disabled={!isEditing}
                placeholder="Stop ID"
                onChange={(e) =>
                  setSelectedRoute({ ...selectedRoute, StopId: e.target.value })
                }
                className="border rounded p-2 w-full"
              />
              <input
                type="text"
                value={selectedRoute.InTime}
                placeholder="In Time"
                disabled={!isEditing}
                onChange={(e) =>
                  setSelectedRoute({ ...selectedRoute, InTime: e.target.value })
                }
                className="border rounded p-2 w-full"
              />
              <input
                type="text"
                value={selectedRoute.OutTime}
                disabled={!isEditing}
                placeholder="Out Time"
                onChange={(e) =>
                  setSelectedRoute({ ...selectedRoute, OutTime: e.target.value })
                }
                className="border rounded p-2 w-full"
              />
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setSelectedRoute(null)}
                className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
              >
                Close
              </button>
              {isEditing && (
                <button
                  onClick={handleUpdate}
                  className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
                >
                  Save
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BusRouteList;
