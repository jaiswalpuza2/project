import React from 'react';
import ActiveStatusBadge from '../../common/ActiveStatusBadge';

const OfficeCard = ({ office }) => {
  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 mb-4 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{office.OfficeName}</h3>
          <p className="text-sm text-gray-600">{office.OfficeShortName}</p>
        </div>
        <ActiveStatusBadge isActive={office.IsActive} />
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-600">Contact</p>
          <p className="text-sm">{office.OfficePhonePrimary}</p>
          <p className="text-sm">{office.OfficeEmail}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Address</p>
          <p className="text-sm">{office.OfficeAddress}</p>
        </div>
      </div>
      
      <div className="mt-4 flex gap-2 text-sm text-gray-600">
        <span>Reg: {office.RegistrationNo}</span>
        <span>•</span>
        <span>PAN: {office.Pan}</span>
        <span>•</span>
        <span>Est: {new Date(office.EstdDate).getFullYear()}</span>
      </div>
    </div>
  );
};

export default OfficeCard;
