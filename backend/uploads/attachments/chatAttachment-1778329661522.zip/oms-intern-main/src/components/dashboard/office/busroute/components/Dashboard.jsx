import React from 'react'
import { FaBusAlt, FaEye, FaEdit, FaTrash } from "react-icons/fa";
import { FiRefreshCw } from "react-icons/fi";



const Dashboard = ({totalroutes}) => {
    // alert(totalroutes);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="flex items-center gap-3 bg-white p-4 border-3 border-gray-300 rounded-lg shadow-1xl ">
              <FaBusAlt className="text-blue-500 text-2xl" />
              <div>
                <p className="text-gray-600 text-bold">Total Routes</p>
                <p className="text-xl font-bold">{totalroutes}</p>
              </div>
            </div>
            <div className="flex items-center gap-3  bg-white p-4 border-3 border-gray-300 rounded-lg shadow-1xl">
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
              <div>
                <p className="text-gray-600 text-bold">Total Bus</p>
                <p className="text-xl font-bold">{totalroutes}</p>
              </div>
            </div>
            
            
          </div>
  );
};

export default Dashboard