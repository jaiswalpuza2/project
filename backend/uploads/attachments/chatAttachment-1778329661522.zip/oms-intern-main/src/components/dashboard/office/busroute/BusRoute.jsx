import React, { useState } from "react";
import BusRouteList from "./components/BusRouteList";
import axiosInstance from "../../../../services/axiosInterceptor";
const BusRoute = () => {
  const [showNewRouteModal, setShowNewRouteModal] = useState(false);

  const [formData, setFormData] = useState({
    routeId: "",
    busId: "",
    stopId: "",
    inTime: "",
    outTime: "",
  });

  const handleNewRoute = () => {
    setShowNewRouteModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // console.log("The data are", formData);
    const payload = {
      RouteId: Number(formData.routeId),
      BusId: Number(formData.busId),
      StopId: Number(formData.stopId),
      InTime: formData.inTime,
      OutTime: formData.outTime
    }

    console.log("Payload to be sent:", payload);

    try{
        const response = await axiosInstance.post("/BusRoute/Insert", payload);
        console.log("Response from adding new route:", response.data);
        setShowNewRouteModal(false);
        setFormData({ routeId: "", busId: "", stopId: "", inTime: "", outTime: "" });
        
        window.location.reload();

    }
    catch(err){
        console.log("Error while adding new route", err);

    }
  };

  return (
    <div>
      {/* heading */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-6 bg-blue-50 shadow-md ">
        <div>
          <h1 className="text-4xl font-bold text-blue-800 mb-2">
            Bus Route <span className="text-blue-900">Management</span>
          </h1>
          <p className="text-lg text-gray-600">
            Manage and organize your bus transportation routes efficiently
          </p>
        </div>
        <button
          className="px-5 py-3 rounded-lg bg-gradient-to-r from-blue-800 to-purple-600 text-white font-medium shadow-2xl hover:opacity-90"
          onClick={handleNewRoute}
        >
          + Add New Route
        </button>
      </div>

      <BusRouteList />

      {/* New Route Modal */}
      {showNewRouteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-blue-50 p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-3xl font-bold mb-3 text-center text-blue-900 rounded-xl p-3 ">
              Add New Route
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="mb-4">
                <label className="block text-gray-700 mb-2 font-bold">Route Id</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter route ID"
                  required
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      routeId: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2 font-bold">Bus Id</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter bus ID"
                  required
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      busId: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2 font-bold">Stop Id</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter stop ID"
                  required
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      stopId: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2 font-bold">In Time</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter in time"
                  required
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      inTime: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 mb-2 font-bold">Out Time</label>
                <input
                  type="text"
                  className="w-full p-2 border rounded"
                  placeholder="Enter out time"
                  required
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      outTime: e.target.value,
                    }))
                  }
                />
              </div>

              <button
                type="submit"
                className="px-5 py-3 bg-blue-900 text-white rounded-lg hover:bg-blue-800 cursor-pointer "
              >
                Add Route
              </button>
              <button className="px-5 py-3 bg-gray-500 text-white rounded-lg ml-5 cursor-pointer hover:bg-gray-600" onClick={(e)=>setShowNewRouteModal(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BusRoute;
