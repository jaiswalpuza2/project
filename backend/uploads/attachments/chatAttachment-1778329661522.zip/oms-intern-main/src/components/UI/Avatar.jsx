import React, { useState } from 'react';

const Avatar = ({ imageUrl, name, size = 'md' }) => {
  const [imageError, setImageError] = useState(false);

  // Size classes mapping
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  // Get initials from name
  const getInitials = (name) => {
    if (!name) return '?';
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Show default avatar with initials if no image or image failed to load
  if (!imageUrl || imageError) {
    return (
      <div 
        className={`${sizeClasses[size]} rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium`}
        title={name}
      >
        {getInitials(name)}
      </div>
    );
  }

  // Show actual image
  return (
    <img
      src={imageUrl}
      alt={name || 'User avatar'}
      onError={() => setImageError(true)}
      className={`${sizeClasses[size]} rounded-full object-cover`}
    />
  );
};

export default Avatar;
