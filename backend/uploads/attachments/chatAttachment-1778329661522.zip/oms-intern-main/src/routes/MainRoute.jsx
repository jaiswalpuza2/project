import React, { Suspense } from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import Home from '../pages/public/Home';
import Login from '../pages/auth/Login';
import NotFound from '../components/common/NotFound';
import DashLayout from '../layouts/dashboard/DashLayout';
import AuthWrapper from './AuthWrapper';
import PublicWrapper from './PublicWrapper';
import { sidebarMenu } from '../constants/SidebarMenu';
import DashboardHome from '../pages/dashboard/home/DashboardHome';
import { HeaderDropDownMenu } from '../constants/HeaderDropDownMenu';

// Helper to auto-generate dashboard routes
const getDashboardRoutes = () =>
  sidebarMenu.flatMap(menu =>
    menu.items?.map(item => ({
      path: item.to,
      element: <Suspense fallback={<div>Loading {item.title}...</div>}><item.component /></Suspense>,
    })) || []
  );

// Helper to generate header dropdown menu routes
const getHeaderDropdownRoutes = () =>
  HeaderDropDownMenu.map(item => ({
    path: item.to.substring(1), // Remove leading slash
    element: <Suspense fallback={<div>Loading {item.title}...</div>}>
      <NotFound /> {/* Placeholder until actual components are created */}
    </Suspense>
  }));

const MainRoutes = () => {
  return (
    <Routes>
      {/* Public Website Routes */}
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<PublicWrapper><Login /></PublicWrapper>} />

      {/* Dashboard Protected Routes */}
      <Route path="/dashboard" element={<AuthWrapper><DashLayout /></AuthWrapper>}>
        {/* Default dashboard route */}
        <Route index element={<DashboardHome />} />
        
        {/* Auto-generated dashboard routes */}
        {getDashboardRoutes().map(({ path, element }) => (
          <Route key={path} path={path} element={element} />
        ))}

        {/* Header dropdown menu routes */}
        {getHeaderDropdownRoutes().map(({ path, element }) => (
          <Route key={path} path={path} element={element} />
        ))}

        {/* Catch all in dashboard */}
        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Catch all (redirect to home) */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default MainRoutes;
