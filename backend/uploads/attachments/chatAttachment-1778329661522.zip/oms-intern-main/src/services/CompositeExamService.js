import axios from "axios";

const API_BASE = "https://office.lunarit.com.np/api";

const authHeader = () => ({
  Authorization: `Bearer ${localStorage.getItem("token")}`,
});

export const getCompositeExamList = (includeBlocked = false) => {
  return axios.get(`${API_BASE}/CompositeExam/GetList/${includeBlocked}`, {
    headers: authHeader(),
  });
};
      
//get
export const getCompositeExamById = (id) => {
  return axios.get(`${API_BASE}/CompositeExam/GetItem/${id}`, {
    headers: authHeader(),
  });
};

//insert
export const insertCompositeExam = (data) => {
  return axios.post(`${API_BASE}/CompositeExam/Insert`, data, {
    headers: authHeader(),
  });
};

//update
export const updateCompositeExam = (data) => {
  return axios.put(`${API_BASE}/CompositeExam/Update`, data, {
    headers: authHeader(),
  });
};

//delete
export const deleteCompositeExam = (id) => {
  return axios.delete(`${API_BASE}/CompositeExam/Block/${id}`, {
    headers: authHeader(),
  });
};
