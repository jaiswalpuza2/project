import axios from 'axios';
import api from './axiosInterceptor';

const authService = {
  login: async (username, password) => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_BASE_API_URL}/auth/login`, 
        { UserName: username, Password: password }
      );
      if (response.data.Token) {  // Backend sends 'Token' with capital T
        localStorage.setItem('token', response.data.Token);
        localStorage.setItem('displayName', response.data.DisplayName);
        localStorage.setItem('expiration', response.data.Expiration);
      }
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  logout: () => {
    localStorage.removeItem('token');
  },


  getCurrentUser: () => {
    const token = localStorage.getItem('token');
    const name = localStorage.getItem('displayName');
    if (token) {
      // Parse user from token or make API call to get user info
      return { isAuthenticated: true, token, name };
    }
    return { isAuthenticated: false };
  },

  checkAuthStatus: async () => {
    try {
      const response = await api.get('/auth/status');
      return response.data;
    } catch (error) {
      return { isAuthenticated: false };
    }
  }
};

export default authService;