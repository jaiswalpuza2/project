import axiosInstance from "./axiosInterceptor";

const dashboardOfficeService = {
    getlist: async (includeInActive = false) => {
        try {
            const response = await axiosInstance.get(`/Office/GetList/${includeInActive}`);
            console.log("response from get office list ", response.data);
            return response.data;
        } catch (error) {
            throw error;
        }
    }
}

export default dashboardOfficeService;