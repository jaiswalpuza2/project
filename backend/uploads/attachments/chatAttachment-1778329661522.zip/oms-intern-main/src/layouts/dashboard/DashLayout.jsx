import React, { useState, useEffect } from 'react'
import DashboardSidebar from './DashboardSidebar'
import DashboardHeader from './DashboardHeader'
import { Outlet } from 'react-router-dom'
import useIsMobile from '../../hooks/useIsMobile'
import useIsTablet from '../../hooks/useTablet'

const DashLayout = () => {
  const isMobile = useIsMobile();
  const isTablet = useIsTablet();
  const [showSidebar, setShowSidebar] = useState(false);

  useEffect(() => {
    // On desktop, show sidebar by default
    // On mobile/tablet, hide by default
    setShowSidebar(!(isMobile || isTablet));
  }, [isMobile, isTablet]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Overlay */}
      {(isMobile || isTablet) && showSidebar && (
        <div 
          className="fixed inset-0 bg-black opacity-60 z-40 transition-opacity duration-300"
          onClick={() => setShowSidebar(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`sidebar ${showSidebar ? '' : '-translate-x-full'}`}>
        <DashboardSidebar setShowSidebar={setShowSidebar} isMobileOrTablet={isMobile || isTablet} />
      </aside>

      {/* Main Content Wrapper - moved header outside of transition wrapper */}
      <DashboardHeader 
        setShowSidebar={setShowSidebar} 
        showSidebar={showSidebar}
        isMobile={isMobile}
        isTablet={isTablet}
      />
      <div className={`transition-all duration-300 ${showSidebar ? 'md:pl-64' : ''}`}>
        <main className="p-2">
          <div className="bg-white rounded-lg shadow-sm p-3 min-h-screen">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}

export default DashLayout
