import { sidebarMenu as sidebarMenuItems } from '../../constants/SidebarMenu';
import { Link, useLocation } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import { Icons } from '../../constants/Icons';
import useIsMobile from '../../hooks/useIsMobile';
import Input from '../../components/UI/Input';

const DashboardSidebar = ({ setShowSidebar, isMobileOrTablet }) => {
  const isMobile = useIsMobile();
  const [searchText, setSearchText] = useState("");
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState([]);
  const [sidebarMenu, setSideBarMenu] = useState(sidebarMenuItems);
  const menuRefs = useRef({});

  useEffect(() => {
    if (searchText === '') {
      setSideBarMenu(sidebarMenuItems);
      // Keep only the active menu expanded when search is cleared
      //this below code matches the route the user is in with the menu to value to decide which menu item to expand
      const activeIndex = sidebarMenuItems.findIndex(item =>
        item.items?.some(subItem => location.pathname.startsWith(`/dashboard/${subItem.to}`))
      );
      if (activeIndex !== -1) {
        setExpandedItems([activeIndex]);
      } else {
        setExpandedItems([]);
      }
    } else {
      const lowercasedFilter = searchText.toLowerCase();
      const filteredData = sidebarMenuItems.map(item => {
        // If the parent matches, keep all children
        if (item.title.toLowerCase().includes(lowercasedFilter)) {
          return item;
        }
        // If any children match, keep only matching children
        if (item.items) {
          const filteredItems = item.items.filter(subItem =>
            subItem.title.toLowerCase().includes(lowercasedFilter)
          );
          if (filteredItems.length > 0) {
            return { ...item, items: filteredItems };
          }
        }
        //in case if neither the parent title matches nor any children titles
        return null;
      }).filter(Boolean); // Remove null items keeps only the true value in the final array returned by map and null is a falsy value

      // Find indices of parent items that have matching subitems
      const expandIndices = filteredData.map((_, index) => index).filter(index =>
        filteredData[index].items?.some(subItem =>
          subItem.title.toLowerCase().includes(lowercasedFilter)
        )
      );

      // Set expanded items to include all parent items with matching subitems
      setExpandedItems(expandIndices);
      setSideBarMenu(filteredData);
    }
  }, [searchText, location.pathname]);

  useEffect(() => {
    const activeIndex = sidebarMenuItems.findIndex(item =>
      item.items?.some(subItem => location.pathname.startsWith(subItem.to))
    );
    if (activeIndex !== -1) {
      setExpandedItems(prev => [...prev, activeIndex]);
    }
  }, [location.pathname]);

  const handleSearchChange = (e) => {
    setSearchText(e.target.value);
  };

  const toggleSubmenu = (index, e) => {
    e.stopPropagation();
    setExpandedItems(prev => {
      const willExpand = !prev.includes(index);
      
      // Close other menus when opening a new one
      const newExpandedItems = willExpand 
        ? [index]  // Only keep the newly expanded menu
        : [];      // Close all menus if we're closing the current one
      
      // Scroll into view if expanding
      if (willExpand) {
        setTimeout(() => {
          const menuItem = menuRefs.current[index];
          if (menuItem) {
            menuItem.scrollIntoView({ 
              behavior: 'smooth', 
              block: 'nearest',
              inline: 'nearest'
            });
          }
        }, 100);
      }
      
      return newExpandedItems;
    });
  };

  const isActive = (path, exact = false) => {
    const fullPath = `/dashboard/${path}`;
    if (exact) {
      return location.pathname === fullPath;
    }
    return location.pathname.startsWith(fullPath) && location.pathname !== "/";
  };

  const isChildActive = (items) => {
    return items?.some(subItem => isActive(subItem.to, true));
  };

  const handleItemClick = (hasChildren) => {
    // Only close sidebar if item has no children and we're on mobile/tablet
    if (isMobileOrTablet && !hasChildren) {
      setShowSidebar(false);
    }
  };

  const handleClearSearch = () => {
    setSearchText("");
  }

  return (
    <aside className={`${isMobile ? "mobile-sidebar" : "desktop-sidebar"} sidebar flex flex-col h-screen`}>
      {/* Sidebar Header with Logo */}
      <div className="flex-shrink-0 px-6 py-2 border-b border-gray-100 h-20">
        <Link to={'/dashboard'} className="flex items-center w-full h-full">
          <img src="/logo.png" alt="Logo" className="w-32 h-auto object-cover" />
        </Link>
      </div>

      {/*  Search */}
      <div className="flex-shrink-0 max-w-xl mx-auto my-3 ">
        <div className="relative">
          <Input
            placeholder="Search..."
            className={`w-full ${searchText ? "pr-10" : "pl-10"} pr-4 py-2 rounded-lg border border-gray-200`}
            onChange={handleSearchChange}
            value={searchText}
          />
          <div className={`${searchText ? "opacity-0 scale-95 -translate-x-4" : "absolute opacity-100 scale-100 translate-x-0"} transition-all duration-200 ease-out absolute inset-y-0 left-0 pl-3 flex items-center`}>
            <Icons.search className="h-5 w-5 text-gray-400" />
          </div>
          {searchText && (
            <button
              onClick={handleClearSearch}
              className={`absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer transition-all duration-300 ease-out`}
            >
              <Icons.close className="h-5 w-5 text-gray-400 hover:text-gray-600" />
            </button>
          )}
        </div>
      </div>

      {/* Sidebar Navigation Menu */}
      <nav className="flex-1 py-6 overflow-y-auto no-scrollbar">
        <ul className="space-y-1.5">
          {sidebarMenu.map((item, index) => (
            <li key={index} ref={el => menuRefs.current[index] = el}>
              <div>
                {/* Parent Menu Item (Link for Home) */}
                {item.to === "/" ? (
                  <Link
                    to={item?.to}
                    onClick={() => handleItemClick(false)}
                    className={`sidebar-item w-full flex items-center group gap-3 px-3 py-2 rounded-md transition-colors duration-200
                      hover:bg-[var(--color-secondary)] hover:text-white
                      ${isActive(item?.to, true)
                        ? 'bg-[var(--color-secondary)] text-white' // Parent is exactly active
                        : isChildActive(item.items)
                          ? 'bg-[var(--color-secondary)] text-white' // Parent has an active child
                          : 'text-gray-700 hover:text-white'
                      }`}
                  >
                    {/* Left-Aligned Icon */}
                    {item?.icon && (
                      <item.icon
                        className={`w-5 h-5 text-gray-500 transition-colors duration-200 
                          ${isActive(item?.to, true) || isChildActive(item?.items) ? 'text-white' : 'group-hover:text-white'}
                        `}
                      />
                    )}

                    {/* Menu Title (Aligned Left with Gap) */}
                    <span className="text-sm font-medium text-start">{item?.title}</span>
                  </Link>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleSubmenu(index, e);
                    }}
                    className={`sidebar-item w-full flex items-center group gap-3 px-3 py-2 rounded-md transition-colors duration-200
                      hover:bg-[var(--color-secondary)] hover:text-white
                      ${isActive(item?.to, true)
                        ? 'bg-[var(--color-secondary)] text-white' // Parent is exactly active
                        : isChildActive(item?.items)
                          ? 'bg-[var(--color-secondary)] text-white' // Parent has an active child
                          : 'text-gray-700 hover:text-white'
                      }`}
                  >
                    {/* Left-Aligned Icon */}
                    {item?.icon && (
                      <item.icon
                        className={`w-5 h-5 text-gray-500 transition-colors duration-200 
                          ${isActive(item?.to, true) || isChildActive(item?.items) ? 'text-white' : 'group-hover:text-white'}
                        `}
                      />
                    )}

                    {/* Menu Title (Aligned Left with Gap) */}
                    <span className="text-sm font-medium text-start">{item?.title}</span>

                    {/* Dropdown Arrow for Expandable Menus */}
                    {item?.items && (
                      <Icons.chevronDown
                        className={`w-4 h-4 transition-transform duration-200 ease-out ml-auto 
                          ${expandedItems.includes(index) ? 'rotate-180' : ''} 
                          ${isActive(item.to) ? 'text-white' :
                            isChildActive(item?.items) ? 'text-white'
                              : 'text-gray-500 group-hover:text-white'
                          }`}
                      />
                    )}
                  </button>
                )}
              </div>

              {/* Submenu (Child Items) */}
              {item?.items && (
                <div className={`overflow-hidden transition-all duration-200 ease-out 
                  ${expandedItems.includes(index) ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}
                `}>
                  <ul className="mt-2 ml-8 space-y-1">
                    {item?.items.map((subItem, subIndex) => (
                      <li key={subIndex}>
                        <Link
                          to={`/dashboard/${subItem.to}`}
                          onClick={() => handleItemClick(false)}
                          className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors duration-200 group
                            ${isActive(subItem?.to, true)
                              ? 'bg-[var(--color-secondary-light)] text-white' // Active child
                              : 'text-gray-700 hover:bg-[var(--color-secondary-light)] hover:text-white'
                            }`}
                        >
                          {subItem?.icon && (
                            <subItem.icon
                              className={`w-5 h-5 text-gray-500 transition-colors duration-200 
                                ${isActive(subItem?.to, true) ? 'text-white' : 'group-hover:text-white'}
                              `}
                            />
                          )}
                          <span>{subItem?.title}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default DashboardSidebar;
