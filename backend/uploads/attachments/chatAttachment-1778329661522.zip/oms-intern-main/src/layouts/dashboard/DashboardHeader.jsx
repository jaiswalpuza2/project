import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Icons } from '../../constants/Icons';
import { useAuth } from '../../context/AuthContext';
import Avatar from '../../components/UI/Avatar';
import { HeaderDropDownMenu } from '../../constants/HeaderDropDownMenu';


const DashboardHeader = ({ setShowSidebar, showSidebar, isMobile, isTablet }) => {
  const { user, logout } = useAuth();
  const [showAvatarDropdown, setShowAvatarDropdown] = useState(false);

  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };



  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowAvatarDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // useEffect(() => {
  //   const urlParams = new URLSearchParams(window.location.search);
  //   const searchQuery = urlParams.get('q');
  //   if (searchQuery) {
  //     setSearchText(decodeURIComponent(searchQuery));
  //   }
  // }, []);

  return (
    <header className="bg-white border-b border-gray-200 h-20 sticky top-0 z-30 w-full">
      <div className={`px-6 h-full flex items-center justify-between transition-all duration-300 ${showSidebar ? 'md:pl-64' : ''}`}>
        <div className="flex items-center gap-4">
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-md hover:bg-gray-100 focus:outline-none transition-colors duration-200 cursor-pointer"
            aria-label="Toggle sidebar"
          >
            <Icons.menu className={`w-6 h-6 ${showSidebar ? 'text-gray-600' : 'text-[var(--color-secondary)] '}`} />
          </button>

        {/* mobile search bar was here later moved to the sidebar component  */} 
           {/* {(isMobile || isTablet) && (
            <button
              onClick={() => setShowMobileSearch(!showMobileSearch)}
              className="p-2 rounded-md hover:bg-gray-100 pl-6 "
              aria-label="Toggle search"
            >
              <Icons.search className="w-5 h-5 text-gray-500 animate-pulse"/>
            </button>
          )}  */}
        </div>



        {/* Mobile Search Overlay */}
        {/* {(isMobile || isTablet) && showMobileSearch && (
          <div className="fixed inset-0 bg-white z-50 p-4">
            <div className="relative flex items-center">
              <Input
                placeholder="Search..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200"
                onChange={handleSearchChange}
                onKeyDown={handleSearch}
                value={searchText}
                autoFocus
              />
              <button
                onClick={() => setShowMobileSearch(false)}
                className="absolute right-2 p-2"
              >
                <Icons.close className="w-6 h-6 text-gray-600" />
              </button>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Icons.search className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
        )} */}

        {/* Avatar with Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setShowAvatarDropdown(!showAvatarDropdown)}
            className="flex items-center focus:outline-none"
          >
            <Avatar 
              imageUrl={user?.imageUrl} 
              name={user?.name || user?.email}
              size="md" 
            />
          </button>

          {showAvatarDropdown && (
            <div className="absolute right-0 top-12 w-48 bg-white shadow-lg rounded-md py-1 border border-gray-100">
              <div className="px-4 py-2 border-b border-gray-100">
                <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
              <ul className="text-sm px-2">
               {HeaderDropDownMenu.map((item) => (
                 <li key={item.to}>
                   <button
                     onClick={() => {
                       if (item.title === "Logout") {
                         logout();
                         navigate('/login');
                       } else {
                         navigate(`/dashboard/${item.to}`);
                       }
                     }}
                     className={`w-full text-left ${item.title === "Logout" ? "text-red-500 hover:bg-red-500 hover:text-white" : "text-gray-700 hover:bg-[var(--color-secondary)] hover:text-white "} text-left px-4 py-2 cursor-pointer rounded-sm`}
                   >
                     {item.title}
                   </button>
                 </li>
               ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;
